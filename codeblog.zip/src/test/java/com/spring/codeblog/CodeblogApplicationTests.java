package com.spring.codeblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
